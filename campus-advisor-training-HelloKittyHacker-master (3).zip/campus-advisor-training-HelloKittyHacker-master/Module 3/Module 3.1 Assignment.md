Apply for GitHub Education Benefits so you can use private repositories within your organization here:

https://education.github.com/discount_requests/new

Once verified you can easily upgrade any GitHub organization being used for academic purposes to [GitHub Team](https://github.com/pricing) with a single click.

Simply visit your GitHub Education benefits page at https://education.github.com/benefits.

Organizations you own will be listed near the bottom of the page:

![screenshot 2019-03-06 at 12 13 06 pm](https://user-images.githubusercontent.com/6764844/53907148-cd043880-4009-11e9-8449-be66e15e13e1.png)

Click the **Upgrade** button next to the organization name to immediately upgrade it for free to GitHub Team.

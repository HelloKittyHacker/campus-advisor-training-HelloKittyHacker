# Module 2.2 Assignment

In this exercise you are going to make a change to this document on GitHub. As mentioned in the video, you can edit documents
on GitHub by clicking the edit button and committing those changes. 

Please follow the steps below:

1. Create a new branch called `edit-module-assignment` on GitHub
2. On the `edit-module-assignment` branch, find this document, `Module 2.2 Assignment` and click the edit button.
3. In the editor for `Module 2.2 Assignment` add your name at the top of the document.
4. Scroll down and commit these changes.
5. On your local repository (on your computer) of the `Campus-Advisor_Training` repository, which we cloned in the last assignment,
fetch and merge this change into your master branch on the command line.

Take a screenshot of your command line showing that you have fetched and merged these changes
and upload your screenshot to a new Issue titled `Module 2.2 Assignment`.

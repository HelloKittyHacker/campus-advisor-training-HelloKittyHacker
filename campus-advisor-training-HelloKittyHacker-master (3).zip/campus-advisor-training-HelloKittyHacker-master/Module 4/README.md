# Welcome to Module 4: GitHub Education

In this module you will be introduced to GitHub Education and some of the opportunities we make available for students.

## Lessons

**All assignment files can be found at the top of the page.**

### Module 4:

[:tv: Module 4 Video](https://youtu.be/ijtovaZpPWY)

:notebook: Module 4 Assignment

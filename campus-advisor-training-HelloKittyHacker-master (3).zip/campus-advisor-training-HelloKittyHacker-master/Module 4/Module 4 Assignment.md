# Module 4 Assignment

Please answer the following questions on the GitHub Education Community forum here:

https://education.github.community/t/module-4-exercise-1-student-programs/26002?u=ericdrosado

1. Describe the existing technical student communities on your campus. Who is served? Where are there gaps?
2. Choose one GitHub Education program. How could it support your on-campus student communities?
3. What would you need to do in order to support the growth of student tech communities on campus?

Please take a screenshot of your post and upload your screenshot to a new Issue titled `Module 4 Assignment`.
